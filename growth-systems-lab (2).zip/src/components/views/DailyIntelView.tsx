import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lightbulb, 
  Brain, 
  Zap, 
  Clock, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Send,
  Loader2,
  AlertCircle,
  Bell,
  Check,
  Trophy,
  ArrowRight,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Flame,
  Sparkles,
  TrendingUp,
  Sliders,
  CheckSquare,
  Compass,
  FileText
} from 'lucide-react';
import { useOperator } from '../../context/OperatorContext';
import { 
  generateDailyIntel, 
  generateQuizQuestions, 
  evaluateQuizAnswer,
  generateGrowthScenario,
  generateReflectionPlan,
  generateCaseJournalResolution,
  evaluateStrategyRedTeam,
  GrowthScenario,
  ScenarioOption,
  ReflectionPlan
} from '../../services/geminiService';
import { DailyIntel, QuizQuestion, DailyReminder, DailyTask } from '../../types';

export const DailyIntelView: React.FC = () => {
  const { 
    roadmap,
    userProfile,
    updateUserProfile,
    actionLedger,
    addActionLedgerItem,
    updateActionLedgerStatus,
    spacedRepetitionCards,
    reviewSpacedTerm,
    learnTermSpaced,
    caseJournalEntries,
    addCaseJournalEntry,
    redTeamAnalyses,
    addRedTeamAnalysis,
    antiCliches,
    addAntiCliche,
    removeAntiCliche
  } = useOperator();

  const [tab, setTab] = useState<'intel' | 'sandbox' | 'quiz' | 'journal' | 'redteam' | 'ledger' | 'profile'>('intel');
  const [intel, setIntel] = useState<DailyIntel | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Personal Case Journal state
  const [journalProblem, setJournalProblem] = useState('');
  const [isAnalyzingJournal, setIsAnalyzingJournal] = useState(false);
  const [journalResult, setJournalResult] = useState<any>(null);

  // Red Team adversarial review state
  const [redTeamThesis, setRedTeamThesis] = useState('');
  const [isAnalyzingRedTeam, setIsAnalyzingRedTeam] = useState(false);
  const [redTeamResult, setRedTeamResult] = useState<any>(null);

  // Spaced Repetition card state
  const [isFrontOfCard, setIsFrontOfCard] = useState(true);

  // Profile Form states
  const [profileBusiness, setProfileBusiness] = useState(userProfile?.business || '');
  const [profileRole, setProfileRole] = useState(userProfile?.role || '');
  const [newCliche, setNewCliche] = useState('');

  // Quiz State
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [sessionCompleted, setSessionCompleted] = useState(false);

  // Simulation State
  const [scenario, setScenario] = useState<GrowthScenario | null>(null);
  const [isLoadingScenario, setIsLoadingScenario] = useState(false);
  const [selectedOption, setSelectedOption] = useState<ScenarioOption | null>(null);

  // Reflection Journal State
  const [journalInput, setJournalInput] = useState('');
  const [isAnalyzingReflection, setIsAnalyzingReflection] = useState(false);
  const [reflectionPlan, setReflectionPlan] = useState<ReflectionPlan | null>(() => {
    const saved = localStorage.getItem('growth_lab_reflection_plan');
    return saved ? JSON.parse(saved) : null;
  });

  // Audio System State
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [speechRate, setSpeechRate] = useState(1);
  const [audioSupported, setAudioSupported] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Reminders & Streak States
  const [reminder, setReminder] = useState<DailyReminder>(() => {
    const saved = localStorage.getItem('growth_lab_reminder');
    return saved ? JSON.parse(saved) : { time: '09:00', enabled: false };
  });
  const [tasks, setTasks] = useState<DailyTask[]>([]);
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );
  const [operatorStreak, setOperatorStreak] = useState(() => {
    const saved = localStorage.getItem('growth_lab_streak');
    return saved ? JSON.parse(saved) : { count: 1, lastActive: '' };
  });

  const activeRoadmapItem = roadmap.find(i => !i.completed) || roadmap[0];

  // Initialize Speech Support
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      setAudioSupported(true);
    }
  }, []);

  // Update Daily Streak
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (operatorStreak.lastActive !== today) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];
      
      let newCount = operatorStreak.count;
      if (operatorStreak.lastActive === yesterdayStr) {
        newCount += 1;
      } else if (operatorStreak.lastActive !== '') {
        newCount = 1; // Reset streak if missed a day
      }
      
      const newStreak = { count: newCount, lastActive: today };
      setOperatorStreak(newStreak);
      localStorage.setItem('growth_lab_streak', JSON.stringify(newStreak));
    }
  }, [operatorStreak]);

  const fetchIntel = useCallback(async (force = false) => {
    const today = new Date().toISOString().split('T')[0];
    const saved = localStorage.getItem(`daily_intel_${today}`);
    
    if (saved && !force) {
      setIntel(JSON.parse(saved));
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const data = await generateDailyIntel(activeRoadmapItem.title, activeRoadmapItem.concepts, userProfile, antiCliches);
      const newIntel: DailyIntel = {
        date: today,
        roadmapId: activeRoadmapItem.id,
        ...data
      };
      setIntel(newIntel);
      localStorage.setItem(`daily_intel_${today}`, JSON.stringify(newIntel));
    } catch (err) {
      setError('Failed to sync with Intel Hub. System offline.');
    } finally {
      setIsLoading(false);
    }
  }, [activeRoadmapItem, userProfile, antiCliches]);

  useEffect(() => {
    fetchIntel();
  }, [fetchIntel]);

  // Load/Generate Scenario
  const loadScenario = useCallback(async (force = false) => {
    const today = new Date().toISOString().split('T')[0];
    const saved = localStorage.getItem(`daily_scenario_${today}`);

    if (saved && !force) {
      setScenario(JSON.parse(saved));
      return;
    }

    setIsLoadingScenario(true);
    setSelectedOption(null);
    try {
      const data = await generateGrowthScenario(activeRoadmapItem.title, activeRoadmapItem.concepts, userProfile);
      setScenario(data);
      localStorage.setItem(`daily_scenario_${today}`, JSON.stringify(data));
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingScenario(false);
    }
  }, [activeRoadmapItem, userProfile]);

  useEffect(() => {
    if (tab === 'sandbox' && !scenario) {
      loadScenario();
    }
  }, [tab, scenario, loadScenario]);

  // Load/Generate Quiz
  useEffect(() => {
    if (tab === 'quiz' && intel && questions.length === 0) {
      const generateQuestions = async () => {
        setIsLoading(true);
        try {
          const qs = await generateQuizQuestions(intel);
          setQuestions(qs);
        } catch (err) {
          console.error(err);
        } finally {
          setIsLoading(false);
        }
      };
      generateQuestions();
    }
  }, [tab, intel, questions.length]);

  // Handle Tasks
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const savedTasks = localStorage.getItem(`tasks_${today}`);
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    } else if (activeRoadmapItem) {
      const newTasks = activeRoadmapItem.exercises.map(ex => ({
        id: Math.random().toString(),
        title: ex,
        completed: false
      }));
      setTasks(newTasks);
      localStorage.setItem(`tasks_${today}`, JSON.stringify(newTasks));
    }
  }, [activeRoadmapItem]);

  const toggleTask = (id: string) => {
    const today = new Date().toISOString().split('T')[0];
    const newTasks = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    setTasks(newTasks);
    localStorage.setItem(`tasks_${today}`, JSON.stringify(newTasks));
  };

  // Notification Logic
  useEffect(() => {
    if (reminder.enabled && permissionStatus === 'granted') {
      const interval = setInterval(() => {
        const now = new Date();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        
        if (currentTime === reminder.time && now.getSeconds() === 0) {
          new Notification("Growth Lab — Time to study!", {
            body: `Today's Module: ${activeRoadmapItem.title}`,
            icon: '/favicon.ico'
          });
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [reminder, permissionStatus, activeRoadmapItem]);

  const requestNotificationPermission = async () => {
    if (typeof Notification !== 'undefined') {
      const permission = await Notification.requestPermission();
      setPermissionStatus(permission);
    }
  };

  const updateReminder = (updates: Partial<DailyReminder>) => {
    const newReminder = { ...reminder, ...updates };
    setReminder(newReminder);
    localStorage.setItem('growth_lab_reminder', JSON.stringify(newReminder));
  };

  // Audio Vocal System
  const toggleSpeech = () => {
    if (!audioSupported || !intel) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    const narrativeText = `
      Case Study: ${intel.caseStudy.company}.
      Core Strategic Lesson: ${intel.caseStudy.insight}.
      Ready to expand core terms. Key term: ${intel.powerTerms.map(t => `${t.name}: ${t.definition}`).join('. ')}
    `;

    const utterance = new SpeechSynthesisUtterance(narrativeText);
    utterance.rate = speechRate;
    
    utterance.onend = () => {
      setIsPlayingAudio(false);
    };

    utteranceRef.current = utterance;
    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Handle Reflection Processing
  const handleReflectionSubmit = async () => {
    if (!journalInput.trim() || !activeRoadmapItem) return;
    setIsAnalyzingReflection(true);
    try {
      const plan = await generateReflectionPlan(journalInput, activeRoadmapItem.title);
      setReflectionPlan(plan);
      localStorage.setItem('growth_lab_reflection_plan', JSON.stringify(plan));
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzingReflection(false);
    }
  };

  // Case Journal Submission
  const handleJournalSubmit = async () => {
    if (!journalProblem.trim() || !activeRoadmapItem) return;
    setIsAnalyzingJournal(true);
    setJournalResult(null);
    try {
      const result = await generateCaseJournalResolution(journalProblem, activeRoadmapItem.title, userProfile, antiCliches);
      setJournalResult(result);
      addCaseJournalEntry({
        id: Math.random().toString(),
        problem: journalProblem,
        date: new Date().toISOString().split('T')[0],
        resolution: result
      });
      setJournalProblem('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzingJournal(false);
    }
  };

  // Red Team strategy thesis submission
  const handleRedTeamSubmit = async () => {
    if (!redTeamThesis.trim()) return;
    setIsAnalyzingRedTeam(true);
    setRedTeamResult(null);
    try {
      const result = await evaluateStrategyRedTeam(redTeamThesis, userProfile);
      setRedTeamResult(result);
      addRedTeamAnalysis({
        id: Math.random().toString(),
        thesis: redTeamThesis,
        date: new Date().toISOString().split('T')[0],
        analysis: result
      });
      setRedTeamThesis('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzingRedTeam(false);
    }
  };

  // Form handle save
  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      business: profileBusiness,
      role: profileRole
    });
  };

  const handleQuizSubmitAnswer = async () => {
    if (!answer.trim()) return;
    setIsEvaluating(true);
    try {
      const evaluation = await evaluateQuizAnswer(
        questions[currentQuestionIndex].question, 
        answer, 
        userProfile, 
        userProfile?.recent_quiz_scores
      );
      const newQuestions = [...questions];
      newQuestions[currentQuestionIndex].evaluation = evaluation;
      
      // Update score in strategic profile
      if (evaluation?.score !== undefined && intel?.powerTerms?.[0]) {
        const currentScores = { ...(userProfile?.recent_quiz_scores || {}) };
        currentScores[intel.powerTerms[0].name] = evaluation.score;
        updateUserProfile({ recent_quiz_scores: currentScores });
      }

      setQuestions(newQuestions);
      setAnswer('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsEvaluating(false);
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setSessionCompleted(true);
    }
  };

  const avgScore = questions.reduce((acc, q) => acc + (q.evaluation?.score || 0), 0) / (questions.filter(q => q.evaluation).length || 1);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 pb-32">
      {/* Top Header Grid */}
      <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 pb-6 border-b border-[#2e2e2e]">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
             <Brain className="text-emerald-400" size={28} /> Daily Intel
          </h1>
          <p className="text-[13px] text-[#a0a0a0] mt-1">Autonomous growth briefings, operational simulations, and interactive diagnostic testing.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-4">
           {/* Navigation Tabs */}
           <div className="flex bg-[#111111] border border-[#2e2e2e] p-1 rounded-sm gap-1 flex-wrap md:flex-nowrap overflow-x-auto max-w-[92vw] sm:max-w-none">
             <button 
              onClick={() => setTab('intel')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'intel' ? 'bg-white text-black' : 'text-[#888888] hover:text-white'}`}
             >
               Briefing
             </button>
             <button 
              onClick={() => setTab('sandbox')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'sandbox' ? 'bg-white text-black' : 'text-[#888888] hover:text-white'}`}
             >
               Sandbox
             </button>
             <button 
              onClick={() => setTab('quiz')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'quiz' ? 'bg-white text-black' : 'text-[#888888] hover:text-white'}`}
             >
               Quiz
             </button>
             <button 
              onClick={() => setTab('journal')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'journal' ? 'bg-white text-black' : 'text-[#888888] hover:text-white'}`}
             >
               Case Journal
             </button>
             <button 
              onClick={() => setTab('redteam')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'redteam' ? 'bg-white text-black' : 'text-[#888888] hover:text-white'}`}
             >
               Red Team
             </button>
             <button 
              onClick={() => setTab('ledger')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'ledger' ? 'bg-white text-black' : 'text-[#888888] hover:text-white'}`}
             >
               Ledger & Reviews
             </button>
             <button 
              onClick={() => setTab('profile')} 
              className={`px-3 md:px-4 h-8 text-[10px] font-bold uppercase tracking-wider rounded-sm transition-all whitespace-nowrap ${tab === 'profile' ? 'bg-emerald-500 text-black font-semibold' : 'text-[#888888] hover:text-white'}`}
             >
               Profile Controls
             </button>
           </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFTSIDE COLUMN (Primary Activity based on Tab) */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* TAB 1: BRIEFING VIEW */}
          {tab === 'intel' && (
            <div className="space-y-8">
              {isLoading && !intel ? (
                <div className="py-24 flex flex-col items-center justify-center space-y-6">
                   <Loader2 className="animate-spin text-emerald-400" size={40} />
                   <p className="text-[11px] font-bold uppercase tracking-widest text-[#6e6e6e] animate-pulse">Syncing Cognitive Core...</p>
                </div>
              ) : error ? (
                <div className="p-12 border border-[#2e2e2e] rounded-sm bg-[#1a1a1a] text-center space-y-4">
                  <AlertCircle className="mx-auto text-red-400" size={32} />
                  <p className="text-sm font-medium text-white">{error}</p>
                  <button onClick={() => fetchIntel(true)} className="btn-standard mx-auto">Retry Sync</button>
                </div>
              ) : intel && (
                <div className="space-y-8">
                  {/* Case Study Block */}
                  <section className="card-container p-6 md:p-8 relative overflow-hidden">
                     <div className="absolute top-0 left-0 w-full h-[1px] bg-white opacity-[0.1]" />
                     <div className="flex items-center justify-between mb-8">
                        <h2 className="label-sm text-emerald-400">Today's Case Study</h2>
                        <span className="px-2 py-1 border border-[#2e2e2e] rounded-sm text-[10px] font-mono uppercase bg-[#0f0f0f] text-[#6e6e6e]">
                          {intel.caseStudy.sourceContext}
                        </span>
                     </div>
                     
                     <div className="space-y-6">
                        <h3 className="text-2xl font-bold text-white tracking-tight leading-tight">
                          {intel.caseStudy.company}: {intel.caseStudy.insight.split('.')[0]}
                        </h3>
                        
                        <div className="space-y-4">
                           <div className="p-6 bg-[#0f0f0f] border border-[#2e2e2e] rounded-sm">
                              <h4 className="label-sm opacity-40 mb-3">Strategic Situation</h4>
                              <p className="body-text text-[#f0f0f0] leading-relaxed">
                                 {intel.caseStudy.situation}
                              </p>
                           </div>
                           <div className="p-6 bg-[#111111] border border-emerald-900/30 rounded-sm relative">
                              <div className="absolute top-0 left-0 bottom-0 w-[2px] bg-emerald-400" />
                              <h4 className="label-sm text-emerald-400 mb-3">Core Insight</h4>
                              <p className="body-text italic leading-relaxed text-[#f0f0f0]">
                                 "{intel.caseStudy.insight}"
                              </p>
                           </div>
                        </div>
                     </div>

                     {/* Sensory Briefing Voiceover Player */}
                     {audioSupported && (
                       <div className="mt-8 p-4 bg-[#111111] border border-[#2e2e2e] rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4">
                          <div className="flex items-center gap-3">
                             <button 
                               onClick={toggleSpeech}
                               className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${isPlayingAudio ? 'bg-red-500 text-white' : 'bg-emerald-400 text-black hover:scale-105'}`}
                             >
                               {isPlayingAudio ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
                             </button>
                             <div>
                                <h4 className="text-[12px] font-bold text-white uppercase tracking-wider">Audio Tactical readout</h4>
                                <p className="text-[10px] text-[#888888] mt-0.5">Synthesized text-to-speech guidance</p>
                             </div>
                          </div>

                          {/* Audio Waveform Viz */}
                          {isPlayingAudio && (
                            <div className="flex items-end gap-1 h-6">
                               <div className="w-1 bg-emerald-400 h-3 animate-pulse" />
                               <div className="w-1 bg-emerald-400 h-5" style={{ animationDelay: '0.2s', animation: 'bounce 0.6s infinite alternate' }} />
                               <div className="w-1 bg-emerald-400 h-2" style={{ animationDelay: '0.4s', animation: 'bounce 0.8s infinite alternate' }} />
                               <div className="w-1 bg-emerald-400 h-4" style={{ animationDelay: '0.1s', animation: 'bounce 0.5s infinite alternate' }} />
                               <span className="text-[9px] font-mono text-emerald-400 uppercase tracking-widest ml-2">BROADCASTING</span>
                            </div>
                          )}

                          <div className="flex items-center gap-3">
                             <Sliders size={14} className="text-[#888888]" />
                             <input 
                               type="range" 
                               min="0.8" 
                               max="1.6" 
                               step="0.1"
                               value={speechRate}
                               onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                               className="w-24 accent-emerald-400 h-1 bg-[#2e2e2e] rounded-lg cursor-pointer"
                             />
                             <span className="text-[10px] font-mono text-[#888888]">{speechRate}x Rate</span>
                          </div>
                       </div>
                     )}
                  </section>

                  {/* Power Vocational Expansion Terms */}
                  <section className="space-y-4">
                     <h2 className="label-sm opacity-40 px-2 tracking-widest uppercase">Fundamental Terms Protocols</h2>
                     <div className="grid grid-cols-1 gap-4">
                        {intel.powerTerms.map((term, i) => (
                          <TermCard key={i} term={term} />
                        ))}
                     </div>
                  </section>

                  {/* Continuous Reflection Section */}
                  <section className="card-container p-6 relative overflow-hidden space-y-6">
                     <div className="flex items-center justify-between">
                        <h3 className="label-sm text-emerald-400 flex items-center gap-2">
                           <FileText size={16} /> Reflective Integration Protocol
                        </h3>
                     </div>
                     <p className="text-[12px] text-[#a0a0a0] leading-relaxed">
                        Synthesize how you will execute today's learnings into your product, workflow, or marketing operations. We'll outline your high-impact action roadmap.
                     </p>
                     
                     <div className="space-y-4">
                        <textarea 
                          value={journalInput}
                          onChange={(e) => setJournalInput(e.target.value)}
                          placeholder="e.g. I will deploy our retention model to target users at the 14-day mark, offering a personalized onboarding review path."
                          className="input-standard w-full h-28 p-4 text-[13px] leading-relaxed resize-none"
                        />
                        <button 
                          onClick={handleReflectionSubmit}
                          disabled={isAnalyzingReflection || !journalInput.trim()}
                          className="btn-action w-full h-12"
                        >
                           {isAnalyzingReflection ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}
                           <span className="text-[10px] font-bold uppercase tracking-widest ml-2">Generate Integration Plan</span>
                        </button>
                     </div>

                     <AnimatePresence>
                       {reflectionPlan && (
                         <motion.div 
                           initial={{ opacity: 0, y: 15 }}
                           animate={{ opacity: 1, y: 0 }}
                           className="pt-6 border-t border-[#2e2e2e] space-y-4"
                         >
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               <div className="p-4 bg-emerald-500/5 border border-emerald-500/15 rounded-sm">
                                  <h4 className="label-sm text-emerald-400 mb-2 uppercase flex items-center gap-1.5">
                                     <CheckCircle2 size={12} /> Execution Agenda
                                  </h4>
                                  <ul className="space-y-2 text-[12px] text-[#d0d0d0]">
                                     {reflectionPlan.actionSteps.map((step, sIdx) => (
                                       <li key={sIdx} className="flex items-start gap-2">
                                          <span className="text-emerald-400 font-mono text-[10px] mt-0.5">{sIdx+1}.</span>
                                          <span>{step}</span>
                                       </li>
                                     ))}
                                  </ul>
                                </div>

                                <div className="p-4 bg-red-500/5 border border-red-900/40 rounded-sm">
                                   <h4 className="label-sm text-red-400 mb-2 uppercase flex items-center gap-1.5">
                                      <AlertCircle size={12} /> Guarded Risks
                                   </h4>
                                   <p className="text-[12px] text-[#d4d4d4] leading-relaxed font-mono">
                                      {reflectionPlan.systemWarning}
                                   </p>
                                </div>
                            </div>
                            
                            <div className="p-4 bg-[#0d0d0d] border border-[#222] rounded-sm">
                               <h4 className="label-sm opacity-40 mb-2 uppercase">Critical Success Metrics</h4>
                               <div className="flex flex-wrap gap-3">
                                  {reflectionPlan.kpiIndicators.map((kpi, kIdx) => (
                                    <span key={kIdx} className="px-3 py-1 bg-[#1a1a1a] border border-[#333] rounded-full text-[11px] font-mono text-[#f0f0f0]">
                                       KPI: {kpi}
                                    </span>
                                  ))}
                               </div>
                            </div>
                         </motion.div>
                       )}
                     </AnimatePresence>
                  </section>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: INTERACTIVE DECISION SANDBOX */}
          {tab === 'sandbox' && (
            <div className="space-y-8">
               {isLoadingScenario ? (
                 <div className="py-24 flex flex-col items-center justify-center space-y-6">
                    <Loader2 className="animate-spin text-emerald-400" size={40} />
                    <p className="text-[11px] font-bold uppercase tracking-widest text-[#6e6e6e] animate-pulse">Synthesizing Tactical Simulation...</p>
                 </div>
               ) : scenario && (
                 <motion.div 
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   className="space-y-6"
                 >
                    <div className="card-container p-6 md:p-8 space-y-6 relative overflow-hidden">
                       <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-emerald-500/30 to-purple-500/10" />
                       <div className="flex items-center justify-between">
                          <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-sm text-[10px] font-mono uppercase tracking-widest">
                             OPERATIONAL SIMULATION
                          </span>
                          <button onClick={() => loadScenario(true)} className="text-[10px] font-bold text-[#888] hover:text-emerald-400 uppercase">
                             New Sandbox
                          </button>
                       </div>

                       <div className="space-y-2">
                          <h2 className="text-2xl font-bold text-white tracking-tight">{scenario.scenarioTitle}</h2>
                          <p className="text-[13px] text-[#cbcbcb] leading-relaxed mt-2 p-4 bg-[#0f0f0f] border border-[#222] rounded-sm">
                             {scenario.scenarioContext}
                          </p>
                       </div>

                       {/* Options Listing */}
                       <div className="grid grid-cols-1 gap-4 pt-4">
                          {scenario.options.map((opt) => (
                            <button 
                              key={opt.id}
                              onClick={() => setSelectedOption(opt)}
                              className={`w-full group p-5 border text-left rounded-sm transition-all flex items-start justify-between gap-4 ${selectedOption?.id === opt.id ? 'border-emerald-400 bg-emerald-500/5' : 'border-[#2e2e2e] bg-[#141414] hover:border-[#444]'}`}
                            >
                               <div className="space-y-1">
                                  <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-widest block mb-1">OPTION {opt.id}</span>
                                  <p className="text-[13px] font-medium text-white group-hover:text-emerald-300 transition-colors">{opt.label}</p>
                               </div>
                               <div className={`w-5 h-5 rounded-full border shrink-0 flex items-center justify-center transition-all ${selectedOption?.id === opt.id ? 'bg-emerald-400 border-emerald-400 text-black' : 'border-[#444]'}`}>
                                  {selectedOption?.id === opt.id && <Check size={12} />}
                               </div>
                            </button>
                          ))}
                       </div>
                    </div>

                    {/* Simulation Feedback Card on Selection */}
                    <AnimatePresence>
                      {selectedOption && (
                        <motion.div 
                          initial={{ opacity: 0, y: 15 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 15 }}
                          className="card-container p-6 border-emerald-500/30 bg-emerald-500/[0.01] space-y-6"
                        >
                           <header className="flex items-center gap-2">
                              <Compass className="text-emerald-400" size={18} />
                              <h3 className="label-sm text-emerald-400 uppercase tracking-widest">TACTICAL SIMULATION FEEDBACK</h3>
                           </header>

                           <p className="text-[13px] text-[#e0e0e0] leading-relaxed italic">
                              "{selectedOption.outcome}"
                           </p>

                           {/* Projected Metrics Dashboard */}
                           <div className="grid grid-cols-3 gap-4 border-t border-[#2e2e2e] pt-4">
                              <div className="p-4 bg-[#0a0a0a] border border-[#222] text-center rounded-sm">
                                 <span className="text-[11px] font-mono text-[#888] uppercase block">REVENUE</span>
                                 <span className="text-lg font-bold text-white mt-1 block">{selectedOption.metricsImpact.revenue}</span>
                              </div>
                              <div className="p-4 bg-[#0a0a0a] border border-[#222] text-center rounded-sm">
                                 <span className="text-[11px] font-mono text-[#888] uppercase block">CONVERSION</span>
                                 <span className="text-lg font-bold text-white mt-1 block">{selectedOption.metricsImpact.conversion}</span>
                              </div>
                              <div className="p-4 bg-[#0a0a0a] border border-[#222] text-center rounded-sm">
                                 <span className="text-[11px] font-mono text-[#888] uppercase block">RETENTION</span>
                                 <span className="text-lg font-bold text-white mt-1 block">{selectedOption.metricsImpact.retention}</span>
                              </div>
                           </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                 </motion.div>
               )}
            </div>
          )}

          {/* TAB 3: TEST ME (QUIZ ENGINE) */}
          {tab === 'quiz' && (
            <div className="max-w-3xl mx-auto space-y-8 animate-fade-in">
               {isLoading && questions.length === 0 ? (
                 <div className="py-24 flex flex-col items-center justify-center space-y-6">
                    <Loader2 className="animate-spin text-emerald-400" size={40} />
                    <p className="text-[11px] font-bold uppercase tracking-widest text-[#6e6e6e] animate-pulse">Generating Diagnostic Challenge...</p>
                 </div>
               ) : sessionCompleted ? (
                 <motion.div 
                   initial={{ opacity: 0, scale: 0.98 }}
                   animate={{ opacity: 1, scale: 1 }}
                   className="card-container p-10 text-center space-y-8"
                 >
                    <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30">
                       <Trophy className="text-emerald-400" size={32} />
                    </div>
                    <div className="space-y-2">
                       <h2 className="text-2xl font-bold text-white tracking-tight uppercase">Diagnostic Complete</h2>
                       <p className="text-sm text-[#a0a0a0]">Feedback stored. Analytical metrics recorded.</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                       <div className="bg-[#111111] p-6 border border-[#2e2e2e] rounded-sm">
                          <div className="text-3xl font-bold text-emerald-400">{avgScore.toFixed(1)}★</div>
                          <div className="label-sm opacity-40 mt-1 uppercase">Avg score</div>
                       </div>
                       <div className="bg-[#111111] p-6 border border-[#2e2e2e] rounded-sm flex flex-col justify-center">
                          <div className="text-[14px] font-bold text-white uppercase tracking-widest">PASS</div>
                          <div className="label-sm opacity-40 mt-1 uppercase">System Status</div>
                       </div>
                    </div>

                    <div className="p-6 bg-[#0f0f0f] border border-[#2e2e2e] rounded-sm text-left">
                       <h3 className="label-sm text-emerald-400 mb-2 uppercase">Operational Advice</h3>
                       <p className="body-text leading-relaxed">
                          Your mastery on <strong>{intel?.powerTerms[0].name}</strong> matches growth tier expectancies. Continue practicing modules to leverage high dynamic scale conversions.
                       </p>
                    </div>

                    <button 
                      onClick={() => {
                        setSessionCompleted(false);
                        setCurrentQuestionIndex(0);
                        setQuestions([]);
                      }}
                      className="btn-action w-full"
                    >
                       Replay challenge
                    </button>
                 </motion.div>
               ) : questions.length > 0 && (
                 <div className="space-y-6">
                    <div className="flex justify-between items-center px-1">
                       <div className="label-sm opacity-40 uppercase tracking-[0.2em] text-[10px]">
                          QUIZ STATUS: {currentQuestionIndex + 1} OF {questions.length} ACTIVE
                       </div>
                       <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest">
                             Session Integrity: {avgScore.toFixed(1)}★
                          </span>
                       </div>
                    </div>

                    <motion.div 
                      key={currentQuestionIndex}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="card-container p-6 md:p-8 space-y-8"
                    >
                       <div className="space-y-4">
                          <span className="text-[9px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-sm font-bold uppercase tracking-widest inline-block">
                             {questions[currentQuestionIndex].type} query
                          </span>
                          <h3 className="text-lg md:text-xl font-bold text-white tracking-tight leading-relaxed">
                            {questions[currentQuestionIndex].question}
                          </h3>
                       </div>

                       {questions[currentQuestionIndex].evaluation ? (
                         <div className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               <div className="p-4 bg-emerald-500/5 border border-emerald-500/15 rounded-sm">
                                  <h4 className="label-sm text-emerald-400 mb-2 uppercase flex items-center gap-1.5 text-[10px]">
                                     <Check className="w-3.5 h-3.5" /> Core Retained
                                  </h4>
                                  <p className="text-[13px] text-[#e0e0e0] leading-relaxed">
                                     {questions[currentQuestionIndex].evaluation?.whatRight}
                                  </p>
                               </div>
                               <div className="p-4 bg-amber-500/5 border border-amber-500/15 rounded-sm">
                                  <h4 className="label-sm text-amber-400 mb-2 uppercase flex items-center gap-1.5 text-[10px]">
                                     <AlertCircle className="w-3.5 h-3.5" /> Gaps Identified
                                  </h4>
                                  <p className="text-[13px] text-[#e0e0e0] leading-relaxed">
                                     {questions[currentQuestionIndex].evaluation?.whatMissed}
                                  </p>
                               </div>
                            </div>
                            
                            <div className="p-5 bg-[#0f0f0f] border border-[#2e2e2e] rounded-sm">
                               <h4 className="label-sm opacity-40 mb-3 text-[10px] uppercase">Superior Operational Answer</h4>
                               <p className="text-[13px] text-[#d4d4d4] leading-relaxed italic">
                                  "{questions[currentQuestionIndex].evaluation?.betterAnswer}"
                               </p>
                            </div>

                            <div className="flex justify-between items-center pt-2">
                               <div className="flex gap-1">
                                  {[...Array(5)].map((_, i) => (
                                    <Zap key={i} size={15} fill={i < (questions[currentQuestionIndex].evaluation?.score || 0) ? '#10b981' : 'none'} className={i < (questions[currentQuestionIndex].evaluation?.score || 0) ? 'text-emerald-400' : 'text-[#333]'} />
                                  ))}
                               </div>
                               <button onClick={nextQuestion} className="btn-standard py-2 px-6 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider">
                                  Commit & Proceed <ArrowRight size={14} />
                               </button>
                            </div>
                         </div>
                       ) : (
                         <div className="space-y-4">
                            <textarea 
                               className="input-standard w-full h-36 p-5 text-[13px] leading-relaxed resize-none"
                               placeholder="Draft your operational strategic response..."
                               value={answer}
                               onChange={(e) => setAnswer(e.target.value)}
                            />
                            <button 
                               onClick={handleQuizSubmitAnswer}
                               disabled={isEvaluating || !answer.trim()}
                               className="btn-action w-full h-12"
                            >
                               {isEvaluating ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
                               <span className="text-[10px] font-bold ml-2 uppercase tracking-widest">SUBMIT RESPONSE EVALUATION</span>
                            </button>
                         </div>
                       )}
                    </motion.div>
                 </div>
               )}
            </div>
          )}
          {/* TAB 4: CASE JOURNAL */}
          {tab === 'journal' && (
            <div className="space-y-6">
              <div className="card-container p-6 space-y-4 relative overflow-hidden text-left bg-zinc-950/20 border border-zinc-900">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-emerald-500/30 to-purple-500/10" />
                <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-sm text-[10px] font-mono uppercase tracking-widest block w-fit">
                  PERSONAL CASE JOURNAL
                </span>
                <h2 className="text-xl font-bold text-white tracking-tight">Eitan Caspi's Framework Solver</h2>
                <p className="text-[12.5px] text-[#888] leading-relaxed">
                  Enter any chaotic real-world situation or growth failure. We will apply today's frameworks (e.g. <strong>{activeRoadmapItem.title}</strong>) modified for your specific business profile while omitting generic advice or marketing jargon.
                </p>
                
                <textarea
                  value={journalProblem}
                  onChange={(e) => setJournalProblem(e.target.value)}
                  placeholder="e.g. Trial-to-paid conversion has declined after we adjusted our onboarding email frequency. Our metrics show lower engagement in the first 48 hours..."
                  className="input-standard w-full h-32 p-4 text-[13px] leading-relaxed resize-none border border-[#2e2e2e] bg-[#0c0c0c] text-white"
                />

                <button
                  onClick={handleJournalSubmit}
                  disabled={isAnalyzingJournal || !journalProblem.trim()}
                  className="btn-action w-full h-12 flex items-center justify-center bg-white text-black font-bold uppercase tracking-widest text-[10px] hover:bg-zinc-200 transition-colors"
                >
                  {isAnalyzingJournal ? <Loader2 className="animate-spin text-black" size={16} /> : <Brain size={16} className="text-black" />}
                  <span className="text-[10px] font-bold text-black uppercase tracking-widest ml-2">Analyze & Solve Problem</span>
                </button>
              </div>

              {/* Show Latest Solver Output */}
              {journalResult && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="card-container p-6 space-y-4 border border-zinc-805 bg-[#070908]"
                >
                  <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider border-b border-[#222] pb-2 text-left">Diagnostic Resolution Breakdown</h3>
                  
                  <div className="space-y-4 text-left">
                    <div>
                      <h4 className="text-[10px] font-mono text-[#888] uppercase tracking-wider text-left">True Crux Bottleneck</h4>
                      <p className="text-[13px] text-zinc-100 mt-1 leading-relaxed bg-[#0d0d0d] p-4 border border-[#222] rounded-sm text-left">{journalResult.situationKey}</p>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-mono text-[#888] uppercase tracking-wider text-left">Strategic Framework Applied</h4>
                      <p className="text-[13px] text-zinc-300 mt-1 leading-relaxed italic bg-zinc-950/40 p-3 rounded-sm border border-zinc-900 text-left">"{journalResult.strategicFramework}"</p>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider text-left">3-Step Tactical Plan</h4>
                      <ul className="space-y-2 mt-2 list-none text-left">
                        {journalResult.tacticalPlan?.map((p: string, idx: number) => (
                          <li key={idx} className="flex gap-2.5 text-[12.5px] text-white leading-relaxed text-left">
                            <span className="text-emerald-400 font-mono text-[11px] mt-0.5">{idx + 1}.</span>
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-5 bg-emerald-500/5 border border-emerald-500/20 rounded-sm text-left font-sans">
                      <h4 className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider text-left">The Immediate 30-Minute Next Action</h4>
                      <p className="text-[13px] text-white mt-1.5 leading-relaxed font-semibold text-left">{journalResult.thirtyMinuteNextAction}</p>
                      
                      <button
                        onClick={() => {
                          addActionLedgerItem({
                            conceptName: journalResult.strategicFramework || activeRoadmapItem.title,
                            action: journalResult.thirtyMinuteNextAction,
                            status: 'committed'
                          });
                          alert('Action successfully committed to your 30-day action ledger!');
                        }}
                        className="mt-3.5 px-3 py-1.5 bg-emerald-400 hover:bg-emerald-300 text-black font-bold uppercase tracking-widest text-[9px] rounded-sm transition-all"
                      >
                        Commit Action to Ledger
                      </button>
                    </div>

                    {journalResult.metricsToTrack?.length > 0 && (
                      <div>
                        <h4 className="text-[10px] font-mono text-[#888] uppercase mb-2 tracking-wider text-left">Monitored Sentinel Metrics</h4>
                        <div className="flex flex-wrap gap-2 text-left">
                          {journalResult.metricsToTrack.map((m: string, idx: number) => (
                            <span key={idx} className="px-2.5 py-1 bg-[#111] border border-[#2e2e2e] rounded text-[10px] font-mono text-emerald-400">
                              {m}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* Journal History */}
              <div className="space-y-4 text-left">
                <h3 className="label-sm opacity-40 px-2 tracking-widest uppercase text-left">Previous Case Entries ({caseJournalEntries?.length || 0})</h3>
                {caseJournalEntries?.map((entry: any) => (
                  <div key={entry.id} className="card-container p-5 space-y-4 bg-[#111111]/70 border-[#2e2e2e]">
                    <div className="flex justify-between items-center text-[10px] text-[#6e6e6e] font-mono uppercase">
                      <span>{entry.date}</span>
                      <span className="text-emerald-400 font-bold">{entry.resolution?.strategicFramework || 'System Framework'}</span>
                    </div>
                    <div>
                      <h4 className="text-[10px] font-mono text-[#6e6e6e] uppercase font-bold text-left">Operator input problem</h4>
                      <p className="text-[13px] text-[#cbd5e1] italic leading-relaxed mt-1 text-left">"{entry.problem}"</p>
                    </div>
                    <div className="pt-3 border-t border-[#222] grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                      <div>
                        <h5 className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest text-left font-bold">Crux Bottleneck</h5>
                        <p className="text-[12.5px] text-[#cbd5e1] leading-relaxed mt-1 text-left">{entry.resolution?.situationKey}</p>
                      </div>
                      <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-sm text-left">
                        <h5 className="text-[10px] font-bold text-emerald-300 uppercase tracking-wide text-left">Committed 30-min tactical action</h5>
                        <p className="text-[12.5px] text-[#cbd5e1] font-sans font-medium leading-relaxed mt-1 text-left">{entry.resolution?.thirtyMinuteNextAction}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {(!caseJournalEntries || caseJournalEntries.length === 0) && (
                  <div className="text-center py-10 text-[#444] border border-dashed border-[#222] rounded-sm font-mono text-[11px] text-center">No previous case entries found. Solve your first case above.</div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: RED TEAM ADVERSARIAL REVIEW */}
          {tab === 'redteam' && (
            <div className="space-y-6 text-left">
              <div className="card-container p-6 space-y-4 relative overflow-hidden text-left bg-zinc-950/20 border border-zinc-900 text-left">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-red-500/30 to-purple-500/10" />
                <span className="px-3 py-1 bg-red-500/10 border border-red-500/30 text-red-350 rounded-sm text-[10px] font-mono uppercase tracking-widest block w-fit">
                  SKEPTICAL BOARD MEMBER MODE
                </span>
                <h2 className="text-xl font-bold text-white tracking-tight text-left">Adversarial Thesis Red-Teaming</h2>
                <p className="text-[12.5px] text-[#888] leading-relaxed select-none text-left">
                  Submit a strategy proposal, growth claim, or marketing hypothesis. Eitan Caspi will put on his Skeptical Board Member hat and logical-attack your idea with 3 game-ending vulnerabilities.
                </p>

                <textarea
                  value={redTeamThesis}
                  onChange={(e) => setRedTeamThesis(e.target.value)}
                  placeholder="e.g. We want to adjust our subscription pricing by bundling premium support as a default, lifting the seat minimum limit to 4 to force SMB upsells..."
                  className="input-standard w-full h-32 p-4 text-[13px] leading-relaxed resize-none border border-[#2e2e2e] bg-[#0c0c0c] text-white focus:border-red-500/40 text-left"
                />

                <button
                  onClick={handleRedTeamSubmit}
                  disabled={isAnalyzingRedTeam || !redTeamThesis.trim()}
                  className="btn-action w-full h-12 flex items-center justify-center bg-red-500/10 border border-red-500 text-red-305 hover:bg-red-500 hover:text-black font-bold uppercase tracking-widest text-[10px]"
                >
                  {isAnalyzingRedTeam ? <Loader2 className="animate-spin text-red-405" size={16} /> : <Zap size={16} />}
                  <span className="text-[10px] font-bold uppercase tracking-widest ml-2">Initiate Logical Attack</span>
                </button>
              </div>

              {/* Show latest attack results */}
              {redTeamResult && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="card-container p-6 space-y-4 border border-zinc-800 bg-[#0a0a0a]"
                >
                  <header className="flex justify-between items-center border-b border-[#222] pb-2 text-left">
                    <h3 className="text-sm font-bold text-red-400 uppercase tracking-wider flex items-center gap-1.5 text-left">
                      <AlertCircle size={14} className="text-red-450" /> ADVERSARIAL FEEDBACK RETRIEVED
                    </h3>
                    <span className="px-2.5 py-1 bg-red-955/20 border border-red-900/30 text-red-300 font-mono rounded text-[11px] font-bold tracking-wider">
                      Defensibility Rating: {redTeamResult.boardDefensibilityScore}/10
                    </span>
                  </header>

                  <div className="space-y-4 text-left font-sans">
                    <div>
                      <h4 className="text-[10px] font-mono text-red-400 uppercase tracking-wider text-left">Fatal Leap Of Faith Assumption</h4>
                      <p className="text-[13.5px] text-white font-medium bg-[#0a0a0a] p-4 border border-red-900/20 rounded-sm leading-relaxed mt-1 text-left">{redTeamResult.keyWeakness}</p>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-mono text-red-400 uppercase tracking-wider text-left">3 Brutal Counter-Attacks</h4>
                      <div className="space-y-3 mt-2 text-left">
                        {redTeamResult.critiques?.map((critique: string, idx: number) => (
                          <div key={idx} className="p-4 bg-[#0a0a0a] border border-[#2e2e2e] rounded flex gap-3 text-[12.5px] leading-relaxed text-zinc-200 text-left">
                            <span className="text-red-400 font-mono text-[11px] mt-0.5 shrink-0 text-left">[Attack {idx + 1}]</span>
                            <span className="text-left">{critique}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {redTeamResult.trapdoor_warning && (
                      <div className="p-4 bg-red-955/15 border border-red-900/40 rounded-sm text-left">
                        <h4 className="text-[10px] font-bold text-red-400 uppercase tracking-wider flex items-center gap-1 text-left"><AlertCircle size={12} /> TRAPDOOR ALERT WARNING</h4>
                        <p className="text-[11px] font-mono text-red-200 mt-1 leading-relaxed text-left">{redTeamResult.trapdoor_warning}</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* History */}
              <div className="space-y-4 text-left">
                <h3 className="label-sm opacity-40 px-2 tracking-widest uppercase font-mono text-left">Logical Attack History ({redTeamAnalyses?.length || 0})</h3>
                {redTeamAnalyses?.map((analysis: any) => (
                  <div key={analysis.id} className="card-container p-5 space-y-3 bg-[#111111]/70 border-[#2e2e2e] border-l-red-900/20">
                    <div className="flex justify-between items-center text-[10px] text-[#6e6e6e] font-mono uppercase font-bold text-left">
                      <span>{analysis.date}</span>
                      <span className="text-red-400 font-bold text-left">DEFENSIBILITY: {analysis.analysis?.boardDefensibilityScore}/10</span>
                    </div>
                    <div className="text-left">
                      <h4 className="text-[10px] font-mono text-[#6e6e6e] uppercase text-left">Proposed strategic thesis</h4>
                      <p className="text-[12.5px] text-[#cbd5e1] italic leading-relaxed mt-1 text-left">"{analysis.thesis}"</p>
                    </div>
                    <div className="p-3.5 bg-red-955/10 border border-red-955/30 rounded-sm text-left">
                      <h5 className="text-[10px] font-bold text-red-400 uppercase text-left font-bold">Fatal Vulnerability Identified</h5>
                      <p className="text-[12.5px] text-[#cbd5e1] leading-relaxed mt-1 text-left">{analysis.analysis?.keyWeakness}</p>
                    </div>
                  </div>
                ))}
                {(!redTeamAnalyses || redTeamAnalyses.length === 0) && (
                  <div className="text-center py-10 text-[#444] border border-dashed border-[#222] rounded-sm font-mono text-[11px] text-center">No previous defensive tests recorded. Stress-test your thesis above.</div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: LEDGER & CARDS */}
          {tab === 'ledger' && (
            <div className="space-y-8 animate-fade-in text-left">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
                
                {/* PART A: 30-DAY ACTION LEDGER */}
                <div className="space-y-6 text-left">
                  <div className="card-container p-6 space-y-4 relative overflow-hidden bg-zinc-950/20 border border-zinc-900 text-left">
                    <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-emerald-500/30 to-emerald-500/10 text-left" />
                    <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-sm text-[10px] font-mono uppercase tracking-widest block w-fit">
                      EXECUTION MATRIX
                    </span>
                    <h2 className="text-xl font-bold text-white tracking-tight text-left">30-day Action Ledger</h2>
                    <p className="text-[12.1px] text-[#888] leading-relaxed font-sans text-left">
                      Every insight requires rapid operational output. Complete these within 30 minutes of logging to establish real velocity.
                    </p>

                    {/* Completion Rates & Metrics Tracker */}
                    {(() => {
                      const total = actionLedger?.length || 0;
                      const completed = actionLedger?.filter((i: any) => i.status === 'completed').length || 0;
                      const rate = total > 0 ? Math.round((completed / total) * 100) : 100;
                      
                      return (
                        <div className="p-4 bg-[#0a0a0a] border border-[#222] rounded-sm space-y-3 text-left">
                          <div className="flex justify-between items-center text-[10.5px] font-mono text-left">
                            <span className="text-[#888] text-left">EXECUTION SCORE LIMITS:</span>
                            <span className={rate < 30 ? 'text-red-450 font-bold' : 'text-emerald-400 font-bold'}>{rate}% RAPID RESOLUTION</span>
                          </div>
                          
                          {/* Progress bar */}
                          <div className="w-full h-1.5 bg-[#111] border border-[#2e2e2e] rounded-sm overflow-hidden text-left">
                            <div className={`h-full transition-all duration-500 ${rate < 30 ? 'bg-red-500' : 'bg-emerald-400'}`} style={{ width: `${rate}%` }} />
                          </div>
                          
                          <div className="flex justify-between text-[10px] text-[#6e6e6e] font-mono uppercase text-[#6e6e6e]">
                            <span>{completed} Completed</span>
                            <span>{total - completed} Outstanding</span>
                          </div>

                          {/* Critical Warning from Page 20 of plan */}
                          {rate < 30 && total >= 3 && (
                            <div className="p-3 bg-red-955/20 border border-red-900/40 rounded-sm text-[11px] text-red-200 leading-relaxed font-mono">
                              ⚠️ Warning: Tool is in Danger of becoming productivity theater. Shift focus to raw execution. Reduce backlog with extreme prejudice.
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>

                  {/* List ledger entries */}
                  <div className="space-y-3 text-left">
                    {actionLedger?.map((item: any) => (
                      <div key={item.id} className={`card-container p-4 flex items-start justify-between gap-4 border transition-all text-left ${item.status === 'completed' ? 'border-emerald-500/10 bg-emerald-500/[0.01]' : 'border-[#2e2e2e]'}`}>
                        <div className="space-y-1 text-left">
                          <div className="flex flex-wrap items-center gap-2 text-left">
                            <span className="text-[9px] font-mono px-1.5 py-0.5 bg-[#111] border border-[#222] text-[#888] uppercase tracking-wider text-left">{item.conceptName}</span>
                            <span className="text-[10px] text-[#555] font-mono">{item.date}</span>
                          </div>
                          <p className={`text-[12.5px] font-medium leading-relaxed mt-0.5 text-left ${item.status === 'completed' ? 'text-[#6e6e6e] line-through' : 'text-[#f0f0f0]'}`}>{item.action}</p>
                          {item.completedDate && (
                            <span className="text-[9px] font-mono text-emerald-400 block pt-0.5 mt-0.5 text-left">✓ Resolved on date: {item.completedDate}</span>
                          )}
                        </div>

                        {/* Status controllers */}
                        <div className="flex gap-2 shrink-0 text-left">
                          {item.status !== 'completed' && (
                            <button
                              onClick={() => updateActionLedgerStatus(item.id, 'completed')}
                              className="p-1 px-1.5 text-emerald-400 hover:bg-emerald-500/10 border border-emerald-500/20 hover:border-emerald-500/40 rounded-sm transition-all"
                              title="Set as Completed"
                            >
                              <Check size={14} />
                            </button>
                          )}
                          {item.status !== 'completed' && (
                            <button
                              onClick={() => updateActionLedgerStatus(item.id, 'abandoned')}
                              className="p-1 px-1.5 text-[#555] hover:border-red-900/50 hover:text-red-450 rounded-sm border border-transparent transition-all"
                              title="Mark as Abandoned"
                            >
                              <AlertCircle size={14} />
                            </button>
                          )}
                          {item.status === 'completed' && (
                            <span className="px-2 py-0.5 text-[9px] bg-emerald-400/10 border border-emerald-400/30 text-emerald-400 uppercase rounded-sm font-bold font-mono">RESOLVED</span>
                          )}
                          {item.status === 'abandoned' && (
                            <span className="px-2 py-0.5 text-[9px] bg-red-400/10 border border-red-400/30 text-red-500 uppercase rounded-sm font-bold font-mono">DORMANT</span>
                          )}
                        </div>
                      </div>
                    ))}
                    {(!actionLedger || actionLedger.length === 0) && (
                      <div className="text-center py-12 text-[#444] font-mono text-[11px] border border-dashed border-[#222] rounded-sm text-center">
                        Action ledger empty. Commit action items via briefings or solver outputs.
                      </div>
                    )}
                  </div>
                </div>

                {/* PART B: SM-2 SPACED REPETITION STUDY MODULES */}
                <div className="space-y-6 text-left">
                  <div className="card-container p-6 space-y-4 relative overflow-hidden bg-zinc-950/20 border border-zinc-900 text-left">
                    <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-purple-500/30 to-purple-500/10 text-left" />
                    <span className="px-3 py-1 bg-purple-500/10 border border-purple-500/20 text-purple-400 rounded-sm text-[10px] font-mono uppercase tracking-widest block w-fit">
                      COGNITIVE RECALL
                    </span>
                    <h2 className="text-xl font-bold text-white tracking-tight font-sans text-left">Vocab Spaced Review</h2>
                    <p className="text-[12.1px] text-[#888] leading-relaxed text-left">
                      Lock advanced strategic metrics and growth vocabulary into long-term memory. Uses the SuperMemo SM-2 algorithmic spacing system.
                    </p>
                  </div>

                  {/* Filter cards due today */}
                  {(() => {
                    const todayStr = new Date().toISOString().split('T')[0];
                    const dueCards = spacedRepetitionCards?.filter((c: any) => !c.dueDate || c.dueDate <= todayStr) || [];
                    
                    return (
                      <div className="space-y-4 text-left">
                        <h3 className="text-xs font-mono text-purple-400 uppercase tracking-widest px-1 text-left">Cards Due Today: {dueCards.length}</h3>
                        
                        {dueCards.length > 0 ? (
                          <div className="card-container p-5 border border-zinc-850 bg-purple-950/[0.01] space-y-4 text-left">
                            
                            {/* The Flash Card */}
                            <div className="p-6 bg-[#0a0a0a] border border-[#2e2e2e] rounded-sm min-h-[220px] flex flex-col justify-between text-left transition-all relative">
                              <div className="text-left">
                                <span className="px-2 py-0.5 bg-purple-500/10 border border-purple-500/20 text-purple-400 text-[10px] rounded-full font-mono uppercase tracking-wide">
                                  {dueCards[0].metricType || 'Hybrid Sentinel'}
                                </span>
                                <h3 className="text-xl font-bold text-white uppercase tracking-wider mt-3.5 text-left">{dueCards[0].termName}</h3>
                              </div>

                              {isFrontOfCard ? (
                                <button
                                  onClick={() => setIsFrontOfCard(false)}
                                  className="w-full h-11 border border-[#3e3e3e] hover:border-purple-500 text-white font-mono uppercase tracking-widest text-[10px] mt-8 rounded-sm hover:-translate-y-0.5 duration-150 transition-all bg-[#111]"
                                >
                                  Flip card to reveal details
                                </button>
                              ) : (
                                <motion.div
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  className="space-y-4 mt-4 pt-4 border-t border-[#1e1e1e] text-left"
                                >
                                  <div>
                                    <h4 className="text-[9px] font-mono text-[#555] uppercase tracking-wider text-left">Definition</h4>
                                    <p className="text-[13px] text-[#cbd5e1] leading-relaxed mt-0.5 text-left">{dueCards[0].definition}</p>
                                  </div>

                                  {dueCards[0].formula && (
                                    <div>
                                      <h4 className="text-[9px] font-mono text-[#555] uppercase tracking-wider text-left">Calculation formula</h4>
                                      <p className="text-[11.5px] font-mono text-emerald-400 bg-emerald-950/15 border border-emerald-900/30 p-2.5 rounded mt-1 overflow-x-auto text-left leading-none">{dueCards[0].formula}</p>
                                    </div>
                                  )}

                                  {dueCards[0].benchmark && (
                                    <div>
                                      <h4 className="text-[9px] font-mono text-[#555] uppercase tracking-wider text-left">Target Benchmark</h4>
                                      <p className="text-[12.5px] text-[#cbd5e1] font-sans font-medium mt-0.5 text-left">{dueCards[0].benchmark}</p>
                                    </div>
                                  )}

                                  <div className="pt-4 border-t border-[#1e1e1e] space-y-2.5 text-left">
                                    <h4 className="text-[9.5px] font-mono text-[#6e6e6e] uppercase tracking-wider text-left">Rate Cognitive Retention Integrity:</h4>
                                    
                                    {/* 0-5 grading buttons */}
                                    <div className="grid grid-cols-6 gap-1.5 text-left select-none">
                                      {[0, 1, 2, 3, 4, 5].map((score) => {
                                        const labels = [
                                          "Blackout", 
                                          "Forgot", 
                                          "Wrong card", 
                                          "Hesitant effort", 
                                          "Hesitant pass", 
                                          "Perfect recall"
                                        ];
                                        return (
                                          <button
                                            key={score}
                                            onClick={() => {
                                              reviewSpacedTerm(dueCards[0].termName, score);
                                              setIsFrontOfCard(true);
                                              alert(`Rated card: ${labels[score]}. SM-2 scheduler updated!`);
                                            }}
                                            className="h-9 rounded bg-[#111] hover:bg-purple-900 border border-[#2e2e2e] hover:border-purple-500/50 text-white font-mono font-bold text-xs flex items-center justify-center transition-all group relative"
                                            title={labels[score]}
                                          >
                                            {score}
                                            {/* Minimal tooltip */}
                                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 bg-black text-[#ccc] border border-[#222] px-2.5 py-1.5 rounded text-[8px] font-sans font-normal opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap mb-2.5 z-10">
                                              {labels[score]}
                                            </span>
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </div>
                          </div>
                        ) : (
                          <div className="p-8 text-center border border-[#2e2e2e] rounded bg-[#0b0b0b] space-y-2.5 text-left font-sans">
                            <span className="text-emerald-400 block text-2xl text-center">✓</span>
                            <h4 className="text-[13px] font-bold text-white text-center">All Spaced Terms Mastered!</h4>
                            <p className="text-[11.5px] text-[#6a6a6a] leading-relaxed max-w-xs mx-auto text-center font-sans mt-0.5 text-center">
                              No cards currently due today. Hit the "+ Add to Spaced Review" option inside the Briefing tab's power terms to queue more terms for scheduling.
                            </p>
                          </div>
                        )}

                        {/* Complete terms deck details */}
                        <div className="space-y-3 text-left">
                          <h4 className="text-xs font-mono text-[#555] uppercase px-1 tracking-widest pt-4 text-left">Cognitive Database Registry ({spacedRepetitionCards?.length || 0})</h4>
                          <div className="space-y-1.5 text-left">
                            {spacedRepetitionCards?.map((card: any) => (
                              <div key={card.termName} className="p-3 bg-[#0a0a0a] border border-[#222] rounded flex items-center justify-between gap-4 text-left">
                                <div className="text-left">
                                  <h4 className="text-[12px] font-bold text-white uppercase tracking-wider text-left">{card.termName}</h4>
                                  <span className="text-[9px] font-mono text-[#555] block mt-0.5 text-left">EFactor: {card.efactor?.toFixed(2)} | Next: {card.dueDate}</span>
                                </div>
                                <span className="px-2 py-0.5 text-[9px] font-mono text-emerald-450 border border-emerald-950/40 bg-emerald-950/25 uppercase rounded">
                                  Rep: {card.repetition || 0}
                                </span>
                              </div>
                            ))}
                            {(!spacedRepetitionCards || spacedRepetitionCards.length === 0) && (
                              <div className="text-center py-4 text-[#444] text-[10px] font-mono">Cognitive scheduler holds 100% capacity free parameters. Add terms to study.</div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: PROFILE */}
          {tab === 'profile' && (
            <div className="space-y-6">
              <div className="card-container p-6 space-y-6 relative overflow-hidden text-left bg-zinc-950/20 border border-zinc-900 text-left">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-emerald-500/30 to-emerald-500/10 text-left" />
                <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-sm text-[10px] font-mono uppercase tracking-widest block w-fit">
                  OPERATIONS CONFLICT RESOLUTION PROFILE
                </span>
                <h2 className="text-xl font-bold text-white tracking-tight text-left">Strategy Operator Context</h2>
                <p className="text-[12.5px] text-[#888] leading-relaxed text-left">
                  Calibrate your strategic coordinates. These variables override Eitan Caspi's synthesis loop to focus strictly on your true business profile, omissions, and team scales, omitting generic platitudes.
                </p>

                <form onSubmit={handleProfileSave} className="space-y-5 text-left">
                  <div className="space-y-2 text-left">
                    <label className="text-[11px] font-mono text-[#888] uppercase block text-left">Business Model & team coordinates</label>
                    <input
                      type="text"
                      value={profileBusiness}
                      onChange={(e) => setProfileBusiness(e.target.value)}
                      placeholder="e.g. B2B SaaS, 18-person team, $1.4M ARR, observability category"
                      className="input-standard w-full h-11 px-4 text-[13px] border border-[#2e2e2e] bg-[#0c0c0c] text-white text-left"
                    />
                  </div>

                  <div className="space-y-2 text-left">
                    <label className="text-[11px] font-mono text-[#888] uppercase block text-left">Operator Title & Role Context</label>
                    <input
                      type="text"
                      value={profileRole}
                      onChange={(e) => setProfileRole(e.target.value)}
                      placeholder="e.g. Head of Growth, also doing PMM"
                      className="input-standard w-full h-11 px-4 text-[13px] border border-[#2e2e2e] bg-[#0c0c0c] text-white text-left"
                    />
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="btn-action px-6 h-11 bg-white text-black font-semibold uppercase tracking-widest text-[10px] rounded-sm hover:bg-neutral-200 transition-colors"
                    >
                      Save Profile Parameters
                    </button>
                  </div>
                </form>
              </div>

              {/* Focus OKRs and Weaknesses */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                
                {/* OKRs */}
                <div className="card-container p-6 space-y-4 bg-zinc-950/20 border border-zinc-900 text-left">
                  <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 text-left">
                    <TrendingUp size={14} /> Sentinel Focus Objectives
                  </h3>
                  <div className="space-y-1.5 text-left">
                    {userProfile?.current_focus_okrs?.map((okr: string, idx: number) => (
                      <div key={idx} className="p-3 bg-[#0a0a0a] border border-[#222] rounded flex gap-2.5 items-center">
                        <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full shrink-0" />
                        <span className="text-[12.5px] text-[#cbd5e1] font-sans leading-relaxed text-left">{okr}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stated Weaknesses */}
                <div className="card-container p-6 space-y-4 bg-zinc-950/20 border border-zinc-900 text-left">
                  <h3 className="text-sm font-bold text-amber-500 uppercase tracking-wider flex items-center gap-1.5 text-left">
                    <AlertCircle size={14} /> Cognitive Gaps & Weaknesses
                  </h3>
                  <div className="space-y-1.5 text-left">
                    {userProfile?.stated_weaknesses?.map((weakness: string, idx: number) => (
                      <div key={idx} className="p-3 bg-[#0a0a0a] border border-[#222] rounded flex gap-2.5 items-center">
                        <span className="w-1.5 h-1.5 bg-amber-400 rounded-full shrink-0" />
                        <span className="text-[12.5px] text-[#cbd5e1] font-sans leading-relaxed text-left">{weakness}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Anti-cliche controller */}
              <div className="card-container p-6 space-y-6 text-left relative overflow-hidden bg-zinc-950/20 border border-zinc-900 text-left">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-red-955/10 text-left" />
                <div className="space-y-1 text-left">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider text-left">Dynamic Marketing Cliché Filter</h3>
                  <p className="text-[12.1px] text-[#888] leading-relaxed font-sans text-left mt-1">
                    Eitan Caspi is restricted from generating any terms in this list. Any presence of these patterns triggers strategic reform passes.
                  </p>
                </div>

                {/* Add dynamic cliche */}
                <div className="flex gap-2 text-left">
                  <input
                    type="text"
                    value={newCliche}
                    onChange={(e) => setNewCliche(e.target.value)}
                    placeholder="e.g. leverage deep learnings, key drivers, game-changing"
                    className="input-standard flex-1 h-10 px-4 text-[13px] border border-[#222] bg-[#0c0c0c] text-white text-left"
                  />
                  <button
                    onClick={() => {
                      if (!newCliche.trim()) return;
                      addAntiCliche(newCliche.trim());
                      setNewCliche('');
                    }}
                    className="h-10 px-4 bg-[#1e1e1e] hover:bg-[#2d2d2d] text-white border border-[#3e3e3e] font-bold uppercase tracking-widest text-[9px] rounded-sm transition-all"
                  >
                    Add Cliché
                  </button>
                </div>

                {/* Show clichés layout badges */}
                <div className="flex flex-wrap gap-2 pt-3 border-t border-[#222] text-left">
                  {antiCliches?.map((cliche: string) => (
                    <span key={cliche} className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-955/10 hover:bg-red-955/20 border border-red-900/30 text-red-300 text-[11px] rounded-full transition-all font-mono">
                      <span>"{cliche}"</span>
                      <button
                        onClick={() => removeAntiCliche(cliche)}
                        className="w-3.5 h-3.5 rounded-full bg-red-900/30 hover:bg-red-500/30 flex items-center justify-center font-bold text-[9px] text-[#ffb5b5] transition-all"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                  {(!antiCliches || antiCliches.length === 0) && (
                    <span className="text-[11px] text-[#555] font-mono py-1">No clichés configured. Autonomous critic operates standard baseline filters.</span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* RIGHTSIDE COLUMN (Side widgets: Routine & Habits) */}
        <div className="lg:col-span-4 space-y-8">
           
           {/* STREAK PROTOCOL */}
           <section className="card-container p-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-3 opacity-[0.03]">
                 <Flame size={48} className="text-orange-500" />
              </div>
              <h3 className="label-sm flex items-center gap-2 text-[11px] uppercase tracking-wider">
                 <Flame size={15} className="text-orange-400" /> Continuous Engagement
              </h3>
              
              <div className="flex items-center gap-4 mt-4">
                 <div className="text-4xl font-bold font-mono tracking-tighter text-white">
                    {operatorStreak.count}
                 </div>
                 <div>
                    <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#cfcfcf]">Day Streak Active</h4>
                    <p className="text-[10px] text-[#888888] mt-0.5">Consecutive micro-learning sessions completed</p>
                 </div>
              </div>
           </section>

           {/* GENERATION MANAGEMENT & RECOVERY */}
           <button 
              onClick={() => fetchIntel(true)}
              disabled={isLoading}
              className="btn-action w-full h-14 tracking-[0.2em] flex-row gap-2 uppercase text-[10px] font-bold rounded-sm"
           >
              {isLoading ? <Loader2 className="animate-spin" size={16} /> : <Zap size={16} />}
              <span>Generate New Intel</span>
           </button>

           {/* DAILY TASK PROTOCOLS */}
           <section className="card-container p-6 space-y-5">
              <header className="flex items-center justify-between">
                 <h3 className="label-sm flex items-center gap-2 text-[11px] uppercase tracking-wider">
                     <CheckSquare size={14} className="text-emerald-400" /> Roadmap Exercises
                 </h3>
              </header>

              <div className="space-y-2">
                 {tasks.map(task => (
                   <button 
                      key={task.id}
                      onClick={() => toggleTask(task.id)}
                      className="w-full flex items-center gap-3 p-3 bg-[#0d0d0d] border border-[#2e2e2e] rounded-sm text-left group hover:border-white/20 transition-all"
                   >
                       <div className={`w-5 h-5 rounded-sm border flex items-center justify-center shrink-0 transition-colors ${task.completed ? 'bg-emerald-500 border-emerald-500' : 'bg-transparent border-[#3a3a3a]'}`}>
                          {task.completed && <Check size={12} className="text-black" />}
                       </div>
                       <span className={`text-[12px] leading-snug ${task.completed ? 'text-[#6e6e6e] line-through' : 'text-[#f0f0f0]'}`}>
                          {task.title}
                       </span>
                   </button>
                 ))}
                 {tasks.length === 0 && (
                   <div className="text-center py-4 text-[11px] text-[#6a6a6a] font-mono">No exercises assigned yet.</div>
                 )}
              </div>
           </section>

           {/* NOTIFICATION HUB */}
           <section className="card-container p-6 space-y-6">
              <div className="flex items-center justify-between">
                 <h3 className="label-sm flex items-center gap-2 text-[11px] uppercase tracking-wider">
                    <Bell size={14} className="text-emerald-400" /> Notifications
                 </h3>
                 {permissionStatus === 'default' && (
                   <button 
                     onClick={requestNotificationPermission}
                     className="text-[9px] font-bold text-emerald-400 hover:underline uppercase"
                   >
                      Authorize Browser
                   </button>
                 )}
              </div>
              
              <div className="flex items-center gap-4">
                 <input 
                   type="time" 
                   value={reminder.time}
                   onChange={(e) => updateReminder({ time: e.target.value })}
                   className="bg-[#0c0c0c] border border-[#2e2e2e] px-3 h-10 rounded-sm text-sm text-white focus:border-white/40 outline-none w-full"
                 />
                 <button 
                   onClick={() => updateReminder({ enabled: !reminder.enabled })}
                   className={`h-10 px-4 rounded-sm text-[10px] font-bold uppercase transition-all border ${reminder.enabled ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' : 'bg-[#1a1a1a] border-[#3a3a3a] text-[#888]'}`}
                 >
                   {reminder.enabled ? 'ON' : 'OFF'}
                 </button>
              </div>
           </section>

        </div>
      </div>
    </div>
  );
};

const TermCard: React.FC<{ term: any }> = ({ term }) => {
  const [isOpen, setIsOpen] = useState(false);

  // Determine a nice badge color depending on metric type
  const getBadgeStyle = (type?: string) => {
    if (!type) return 'bg-[#111] border-[#333] text-[#777]';
    const t = type.toLowerCase();
    if (t.includes('leading')) {
      return 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400';
    } else if (t.includes('lagging')) {
      return 'bg-purple-500/10 border-purple-500/20 text-purple-400';
    } else {
      return 'bg-blue-500/10 border-blue-500/20 text-blue-400';
    }
  };

  return (
    <div className="card-container overflow-hidden group border border-[#2e2e2e]">
       <button 
         onClick={() => setIsOpen(!isOpen)}
         className="w-full p-4 flex items-center justify-between group-hover:bg-[#151515] transition-colors"
       >
          <div className="flex items-center gap-4 text-left">
             <div className="w-10 h-10 rounded bg-[#0a0a0a] border border-[#222] flex items-center justify-center text-emerald-400 shrink-0">
                <TrendingUp size={18} />
             </div>
             <div>
                <div className="flex flex-wrap items-center gap-2">
                   <h3 className="text-[14px] font-bold text-white uppercase tracking-wider">{term.name}</h3>
                   {term.metricType && (
                     <span className={`px-2 py-0.5 border text-[9px] font-mono rounded-full font-bold uppercase tracking-wider ${getBadgeStyle(term.metricType)}`}>
                        {term.metricType}
                     </span>
                   )}
                </div>
                <p className="text-[12px] text-[#888888] mt-1 line-clamp-1 max-w-[200px] sm:max-w-md md:max-w-xl">{term.definition}</p>
             </div>
          </div>
          {isOpen ? <ChevronUp size={16} className="text-[#6e6e6e] shrink-0" /> : <ChevronDown size={16} className="text-[#6e6e6e] shrink-0" />}
       </button>
       <AnimatePresence>
          {isOpen && (
            <motion.div 
               initial={{ height: 0, opacity: 0 }}
               animate={{ height: 'auto', opacity: 1 }}
               exit={{ height: 0, opacity: 0 }}
               className="px-4 pb-4 overflow-hidden"
            >
               <div className="p-4 bg-[#0a0a0a] border-t border-[#222] rounded-sm mt-0 space-y-4">
                  <div>
                     <h4 className="label-sm opacity-35 mb-1 text-[9px] uppercase">Strategic Definition</h4>
                     <p className="text-[13px] text-[#f0f0f0] leading-relaxed">{term.definition}</p>
                  </div>

                  {term.formula && (
                    <div className="p-3 bg-[#0d0d0d] border border-[#222] rounded-sm">
                       <h4 className="label-sm opacity-35 mb-1 text-[9px] uppercase">Calculation Formula</h4>
                       <p className="text-[12px] font-mono text-emerald-400 bg-black/40 px-2 py-1.5 rounded-sm inline-block">{term.formula}</p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     {term.benchmark && (
                       <div className="p-3 bg-emerald-500/[0.02] border border-emerald-500/10 rounded-sm">
                          <h4 className="label-sm text-emerald-400 mb-1 text-[9px] uppercase">Operational Target Benchmark</h4>
                          <p className="text-[13px] text-[#f0f0f0] font-sans font-medium">{term.benchmark}</p>
                       </div>
                     )}
                     
                     {term.impactOnBusiness && (
                       <div className="p-3 bg-blue-500/[0.02] border border-blue-500/10 rounded-sm">
                          <h4 className="label-sm text-blue-400 mb-1 text-[9px] uppercase">Direct Growth Leverage</h4>
                          <p className="text-[13px] text-[#f0f0f0] font-sans leading-relaxed">{term.impactOnBusiness}</p>
                       </div>
                     )}
                  </div>

                  <div>
                     <h4 className="label-sm opacity-35 mb-1 text-[9px] uppercase">Operational/Decision Instance</h4>
                     <p className="text-[13px] text-[#a0a0a0] leading-relaxed italic">"{term.example}"</p>
                  </div>
               </div>
            </motion.div>
          )}
       </AnimatePresence>
    </div>
  );
};
