import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  RoadmapItem, 
  LibraryCard, 
  AuditSubmission, 
  ContentIdea, 
  TopicLogEntry, 
  BookEntry, 
  QuestionEntry, 
  WeeklyCommitment, 
  SkillLevel,
  ConsultingProduct,
  ClientPipeline,
  CaseStudy,
  ReverseEngineeringItem,
  UserProfile,
  ActionLedgerItem,
  SpacedRepetitionCard,
  CaseJournalEntry,
  RedTeamAnalysis
} from '../types';
import { ROADMAP_DATA, INITIAL_LIBRARY, CONSULTING_PACKAGES } from '../constants';

interface OperatorStore {
  roadmap: RoadmapItem[];
  library: LibraryCard[];
  audits: AuditSubmission[];
  contentIdeas: ContentIdea[];
  topicLogs: TopicLogEntry[];
  books: BookEntry[];
  questions: QuestionEntry[];
  weeklyCommitment: WeeklyCommitment;
  skillLevels: SkillLevel[];
  products: ConsultingProduct[];
  clients: ClientPipeline[];
  cases: CaseStudy[];
  reverseItems: ReverseEngineeringItem[];
  
  // Custom operators state
  userProfile: UserProfile;
  actionLedger: ActionLedgerItem[];
  spacedRepetitionCards: SpacedRepetitionCard[];
  caseJournalEntries: CaseJournalEntry[];
  redTeamAnalyses: RedTeamAnalysis[];
  antiCliches: string[];
  
  // Actions
  updateRoadmap: (id: string, updates: Partial<RoadmapItem>) => void;
  toggleLibraryBookmark: (id: string) => void;
  addAudit: (audit: AuditSubmission) => void;
  addContentIdea: (idea: ContentIdea) => void;
  updateContentIdea: (id: string, updates: Partial<ContentIdea>) => void;
  addTopicLog: (log: TopicLogEntry) => void;
  addBook: (book: BookEntry) => void;
  addQuestion: (q: QuestionEntry) => void;
  updateQuestion: (id: string, updates: Partial<QuestionEntry>) => void;
  updateSkill: (skill: SkillLevel['skill'], level: number) => void;
  updateProduct: (id: string, updates: Partial<ConsultingProduct>) => void;
  addClient: (client: ClientPipeline) => void;
  updateClient: (id: string, updates: Partial<ClientPipeline>) => void;
  addCase: (caseItem: CaseStudy) => void;
  updateCase: (id: string, updates: Partial<CaseStudy>) => void;
  addReverseItem: (item: ReverseEngineeringItem) => void;
  
  // Custom operators actions
  updateUserProfile: (updates: Partial<UserProfile>) => void;
  addActionLedgerItem: (item: Omit<ActionLedgerItem, 'id'>) => void;
  updateActionLedgerStatus: (id: string, status: ActionLedgerItem['status']) => void;
  reviewSpacedTerm: (termName: string, score: number) => void;
  learnTermSpaced: (term: any) => void;
  addCaseJournalEntry: (entry: CaseJournalEntry) => void;
  addRedTeamAnalysis: (analysis: RedTeamAnalysis) => void;
  addAntiCliche: (phrase: string) => void;
  removeAntiCliche: (phrase: string) => void;

  resetData: () => void;
}

const OperatorContext = createContext<OperatorStore | undefined>(undefined);

const STORAGE_KEY = 'growth_lab_operator_data_v2';

export const OperatorProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<any>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
    
    return {
      roadmap: ROADMAP_DATA,
      library: INITIAL_LIBRARY,
      audits: [],
      contentIdeas: [],
      topicLogs: [],
      books: [],
      questions: [],
      weeklyCommitment: { hoursStudied: 0, contentCreatedCount: 0, insightsCaptured: 0 },
      skillLevels: [
        { skill: 'Funnel Strategy', level: 1 },
        { skill: 'CRM', level: 1 },
        { skill: 'Sales', level: 1 },
        { skill: 'Content', level: 1 },
        { skill: 'Analytics', level: 1 },
        { skill: 'Psychology', level: 1 },
        { skill: 'Consulting', level: 1 },
        { skill: 'Ads', level: 1 },
        { skill: 'Retention', level: 1 },
      ],
      products: CONSULTING_PACKAGES,
      clients: [],
      cases: [],
      reverseItems: [],
      
      // Default user profile
      userProfile: {
        business: "B2B SaaS, 18-person team, $1.4M ARR, observability category",
        role: "Head of Growth, also doing PMM",
        current_focus_okrs: ["lift trial-to-paid by 35%", "open EU mid-market"],
        stated_weaknesses: ["pricing intuition", "lifecycle email", "B2B SEO"],
        recent_quiz_scores: { "LTV:CAC": 3, "NRR drivers": 4, "PLG loops": 2 },
        last_5_struggles: ["got annual pricing modeling wrong", "missed product-qualification threshold validation"],
        do_not_repeat_examples: ["Notion onboarding", "Slack viral loop"]
      },
      actionLedger: [],
      spacedRepetitionCards: [],
      caseJournalEntries: [],
      redTeamAnalyses: [],
      antiCliches: [
        "product-market fit",
        "growth hacking",
        "build a moat",
        "in today's competitive landscape",
        "leverage data-driven insights",
        "unlocked value",
        "game changer",
        "unlock synergies"
      ]
    };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const updateState = (key: string, value: any) => {
    setData((prev: any) => ({ ...prev, [key]: value }));
  };

  const store: OperatorStore = {
    ...data,
    updateRoadmap: (id, updates) => {
      updateState('roadmap', data.roadmap.map((item: any) => item.id === id ? { ...item, ...updates } : item));
    },
    toggleLibraryBookmark: (id) => {
      updateState('library', data.library.map((item: any) => item.id === id ? { ...item, isBookmarked: !item.isBookmarked } : item));
    },
    addAudit: (audit) => updateState('audits', [audit, ...data.audits]),
    addContentIdea: (idea) => updateState('contentIdeas', [idea, ...data.contentIdeas]),
    updateContentIdea: (id, updates) => {
      updateState('contentIdeas', data.contentIdeas.map((item: any) => item.id === id ? { ...item, ...updates } : item));
    },
    addTopicLog: (log) => {
      setData((prev: any) => ({
        ...prev,
        topicLogs: [log, ...prev.topicLogs],
        weeklyCommitment: {
          ...prev.weeklyCommitment,
          insightsCaptured: prev.weeklyCommitment.insightsCaptured + 1
        }
      }));
    },
    addBook: (book) => updateState('books', [book, ...data.books]),
    addQuestion: (q) => updateState('questions', [q, ...data.questions]),
    updateQuestion: (id, updates) => {
      updateState('questions', data.questions.map((item: any) => item.id === id ? { ...item, ...updates } : item));
    },
    updateSkill: (skill, level) => {
      updateState('skillLevels', data.skillLevels.map((s: any) => s.skill === skill ? { ...s, level } : s));
    },
    updateProduct: (id, updates) => {
      updateState('products', data.products.map((p: any) => p.id === id ? { ...p, ...updates } : p));
    },
    addClient: (client) => updateState('clients', [client, ...data.clients]),
    updateClient: (id, updates) => {
      updateState('clients', data.clients.map((c: any) => c.id === id ? { ...c, ...updates } : c));
    },
    addCase: (caseItem) => updateState('cases', [caseItem, ...data.cases]),
    updateCase: (id, updates) => {
      updateState('cases', data.cases.map((c: any) => c.id === id ? { ...c, ...updates } : c));
    },
    addReverseItem: (item) => updateState('reverseItems', [item, ...data.reverseItems]),
    
    // Custom operators handlers implementation
    updateUserProfile: (updates) => {
      setData((prev: any) => ({
        ...prev,
        userProfile: { ...prev.userProfile, ...updates }
      }));
    },
    addActionLedgerItem: (item) => {
      const newItem = {
        ...item,
        id: Math.random().toString(),
        date: new Date().toISOString().split('T')[0]
      };
      setData((prev: any) => ({
        ...prev,
        actionLedger: [newItem, ...(prev.actionLedger || [])]
      }));
    },
    updateActionLedgerStatus: (id, status) => {
      setData((prev: any) => ({
        ...prev,
        actionLedger: (prev.actionLedger || []).map((item: any) => {
          if (item.id === id) {
            return {
              ...item,
              status,
              completedDate: status === 'completed' ? new Date().toISOString().split('T')[0] : item.completedDate
            };
          }
          return item;
        })
      }));
    },
    reviewSpacedTerm: (termName, score) => {
      setData((prev: any) => {
        const cards = [...(prev.spacedRepetitionCards || [])];
        const cardIndex = cards.findIndex((c: any) => c.termName === termName);
        if (cardIndex === -1) return prev;
        
        const card = cards[cardIndex];
        
        // SM-2 values calculation
        let interval = 1;
        let repetition = card.repetition || 0;
        let efactor = card.efactor || 2.5;

        if (score >= 3) {
          if (repetition === 0) {
            interval = 1;
          } else if (repetition === 1) {
            interval = 6;
          } else {
            interval = Math.round(card.interval * efactor);
          }
          repetition++;
        } else {
          repetition = 0;
          interval = 1;
        }

        efactor = efactor + (0.1 - (5 - score) * (0.08 + (5 - score) * 0.02));
        if (efactor < 1.3) efactor = 1.3;

        const updatedCard = {
          ...card,
          interval,
          repetition,
          efactor,
          lastReviewed: new Date().toISOString().split('T')[0],
          dueDate: new Date(Date.now() + interval * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        };

        const updatedCards = [...cards];
        updatedCards[cardIndex] = updatedCard;

        return {
          ...prev,
          spacedRepetitionCards: updatedCards
        };
      });
    },
    learnTermSpaced: (term) => {
      setData((prev: any) => {
        const cards = [...(prev.spacedRepetitionCards || [])];
        const exists = cards.some((c: any) => c.termName === term.name);
        if (exists) return prev; 

        const newCard = {
          termName: term.name,
          definition: term.definition,
          formula: term.formula || "",
          benchmark: term.benchmark || "",
          metricType: term.metricType || "Hybrid Sentinel",
          impactOnBusiness: term.impactOnBusiness || "",
          example: term.example || "",
          interval: 1,
          repetition: 0,
          efactor: 2.5,
          dueDate: new Date().toISOString().split('T')[0]
        };

        return {
          ...prev,
          spacedRepetitionCards: [newCard, ...cards]
        };
      });
    },
    addCaseJournalEntry: (entry) => {
      setData((prev: any) => ({
        ...prev,
        caseJournalEntries: [entry, ...(prev.caseJournalEntries || [])]
      }));
    },
    addRedTeamAnalysis: (analysis) => {
      setData((prev: any) => ({
        ...prev,
        redTeamAnalyses: [analysis, ...(prev.redTeamAnalyses || [])]
      }));
    },
    addAntiCliche: (phrase) => {
      setData((prev: any) => {
        const existing = prev.antiCliches || [];
        if (existing.includes(phrase.toLowerCase())) return prev;
        return {
          ...prev,
          antiCliches: [...existing, phrase.toLowerCase()]
        };
      });
    },
    removeAntiCliche: (phrase) => {
      setData((prev: any) => {
        const existing = prev.antiCliches || [];
        return {
          ...prev,
          antiCliches: existing.filter((p: string) => p !== phrase.toLowerCase())
        };
      });
    },
    resetData: () => {
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };

  return <OperatorContext.Provider value={store}>{children}</OperatorContext.Provider>;
};

export const useOperator = () => {
  const context = useContext(OperatorContext);
  if (!context) throw new Error('useOperator must be used within OperatorProvider');
  return context;
};
