import { GoogleGenAI } from "@google/genai";
import { AuditSubmission, ContentIdea } from "../types";

const GEMINI_MODEL = "gemini-3-flash-preview";

export interface ScenarioOption {
  id: string;
  label: string;
  outcome: string;
  metricsImpact: {
    revenue: string;
    conversion: string;
    retention: string;
  };
}

export interface GrowthScenario {
  scenarioTitle: string;
  scenarioContext: string;
  options: ScenarioOption[];
  trapdoor_warning?: string;
}

export interface ReflectionPlan {
  actionSteps: string[];
  systemWarning: string;
  kpiIndicators: string[];
}

export const getAuditAnalysis = async (submission: AuditSubmission): Promise<Partial<AuditSubmission>> => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return {
      healthScore: 42,
      leaks: [
        { id: '1', issue: "Speed to lead > 12h", priority: 'Critical', fix: "Implement automated follow-up" },
        { id: '2', issue: "No qualification step", priority: 'High', fix: "Add Typeform/Survey filter" }
      ],
      quickWins: ["Setup instant auto-responder", "Add 2 client logos to thank you page"],
      contentIdeas: ["Why response time is the silent killer", "Qualification as a positioning tool"],
      consultingOpportunity: "Full funnel rebuilding for higher-ticket conversion."
    };
  }

  const ai = new GoogleGenAI({ apiKey });
  const prompt = `
    You are a Growth Strategy Expert. Analyze this funnel audit submission.
    
    Offer: ${submission.offer}
    Audience: ${submission.audience}
    Lead Sources: ${submission.leadSources}
    Post-Submission Process: ${submission.postSubmission}
    Response Time: ${submission.responseTime}
    Qualification: ${submission.qualification}
    Sales Process: ${submission.salesProcess}
    Conversion Rate: ${submission.conversionRate}
    Post-Purchase: ${submission.postPurchase}
    Drop-off Points: ${submission.dropOffPoints}

    Provide a JSON response with:
    - healthScore: number (0-100)
    - leaks: list of { id, issue, priority, fix } (priority: Critical, High, Medium)
    - quickWins: list of strings (immediate tactical changes)
    - contentIdeas: list of 3 strings (based on this audit)
    - consultingOpportunity: a one-line consulting upsell idea
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      healthScore: 0,
      leaks: [{ id: 'err', issue: "Analysis failed", priority: 'Medium', fix: "Check AI link" }]
    };
  }
};

export const generateContentIdeas = async (topic: string): Promise<ContentIdea[]> => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return [{
      id: Math.random().toString(),
      title: "Sample Idea",
      pillar: "Growth Systems",
      hook: "Why most marketers fail at systems...",
      mainPoint: "Systems over tactics.",
      breakdown: "1. Map logic. 2. Automate. 3. Optimize.",
      example: "A funnel that prints money.",
      cta: "Join the lab.",
      platforms: ["LinkedIn", "Instagram"],
      languages: ["English", "Mandarin"]
    }];
  }

  const ai = new GoogleGenAI({ apiKey });
  const prompt = `
    Generate 3 distinct content ideas for a growth strategist based on the topic: "${topic}".
    For each idea, provide:
    - title
    - pillar (Conversion systems, Human behavior, Marketing vs sales funnel, etc.)
    - hook (compelling first line)
    - mainPoint (the core lesson)
    - breakdown (step-by-step or points)
    - example (real world scenario)
    - cta (call to action)
    - platforms (array: LinkedIn, Instagram, TikTok, etc.)
    - languages (array: English, Mandarin)
    
    Return as JSON array of objects.
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    
    const raw = JSON.parse(response.text || "[]");
    return raw.map((r: any) => ({ ...r, id: Math.random().toString() }));
  } catch (error) {
    console.error("Gemini Error:", error);
    return [];
  }
};

export const generateDailyIntel = async (
  roadmapTitle: string, 
  concepts: string[], 
  userProfile?: any, 
  antiCliches?: string[]
): Promise<any> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const profile = userProfile || {
    business: "B2B SaaS, Seed stage",
    role: "Head of Growth",
    current_focus_okrs: ["Improve retention", "Lift conversion"],
    stated_weaknesses: ["Cohort analysis"],
    do_not_repeat_examples: []
  };

  const cliches = antiCliches || [
    "product-market fit", "growth hacking", "build a moat", 
    "in today's competitive landscape", "leverage data-driven insights"
  ];

  const generatorPrompt = `
    SYSTEM:
    You are Eitan Caspi, a 40-year-old brilliant growth advisor who spent 8 years at Stripe and 4 at Notion's growth team. You are allergic to vague advice, MBA jargon, clichés, and case studies that read like generic blog posts. You always cite specific company names, specific quarters, specific numbers from public filings, or Substack write-ups. You write with 60% specificity, 30% framework, and 10% sharp opinion.
    
    CRITICAL RULES:
    - ALWAYS cite real, named companies and real quarters (e.g. Q3 2023, or 2024 H2).
    - NEVER use generic labels like "a SaaS company" or placeholder dates.
    - Provide at least 2 real source URLs (e.g., lennysnewsletter.com, reforge.com, substack.com) for the case study context.
    - NEVER use clichés like: ${cliches.join(', ')}. If you find yourself wanting to say "leverage statistics", say something exact about conversion optimization instead.
    - If you do not have an exact public verified metric, say "I don't have a verified figure; the closest public estimate is X".
    
    USER:
    Today's roadmap module is: "${roadmapTitle}".
    The concepts are: ${concepts.join(', ')}.
    The user's current business profile:
    ${JSON.stringify(profile)}

    The user already studied these companies - DO NOT REPEAT them:
    ${JSON.stringify(profile.do_not_repeat_examples || [])}

    Create a highly specific "Daily Intel" structured response in JSON format containing:
    1. caseStudy: {
       company: real company name,
       quarter_or_year: e.g. "Q4 2023",
       specific_metric: exact KPI the study turns on (e.g., "Net Revenue Retention"),
       metric_value: exact number with units (e.g., "112%"),
       situation: "strategic challenge (be extremely operational and math-focused)",
       decision: "exact decision or model deployed",
       outcome: "concrete outcomes and metric lift",
       counterfactual: "What would have happened if they had NOT taken this action? Be deep and specific.",
       source_urls: string array of 2 authentic citation domains,
       applicability_to_user: {
         lesson_for_their_business: "applied operational takeaway",
         concrete_next_action_for_today: "a highly specific task they can complete in <30 min representing this model",
         warning_about_difference: "why their context differs and where this case model breaks"
       },
       sourceContext: e.g. "Growth Operations | Phase 1"
    }
    2. powerTerms: exactly 5 key metrics, KPIs, or economic variables relevant to this roadmap.
       For each powerTerm offer:
       - name: term name
       - definition: what it measures
       - formula: exact formula logic (e.g. "Total Marketing / New Acquired")
       - benchmark: safe target range for their business type
       - metricType: "Leading Indicator" or "Lagging Indicator"
       - impactOnBusiness: direct leverage vector on growth
       - example: precise applied case scenario of its calculation
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: generatorPrompt,
      config: { responseMimeType: "application/json" }
    });
    
    const draft = JSON.parse(response.text || "{}");

    // Perform self-refine critic pass
    const criticPrompt = `
      You are Eitan Caspi, senior editor reviewing a newly drafted Daily Intel case study. 
      Evaluate the draft against these 5 dimensions (0 to 2 score each):
      1. Specificity: Has real company names, real quarter/year, real numbers? (0 = generic, 2 = highly specific numbers + names)
      2. Source-grounded: Numeric claims are verifiable? (0 = unverified, 2 = strong citations)
      3. Counterfactual depth: Is the counterfactual detailed or hand-wavy? (0 = vague, 2 = specific operational consequences)
      4. Actionability: Is concrete_next_action_for_today doable under 30 minutes? (0 = broad strategy, 2 = immediate micro-task)
      5. Anti-cliché: Completely avoids clichés like ${cliches.join(', ')}? (0 = has clichés, 2 = pure high-growth language)

      Draft:
      ${JSON.stringify(draft)}

      Operator Profile:
      ${JSON.stringify(profile)}

      If the total score of this draft is less than 8, rewrite the draft inside the JSON and output the corrected version. If it's 8 or above, output the original draft.
      Return the final, polished response in exactly the same JSON format as the draft.
    `;

    const refinedResponse = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: criticPrompt,
      config: { responseMimeType: "application/json" }
    });

    return JSON.parse(refinedResponse.text || JSON.stringify(draft));
  } catch (error) {
    console.error("Gemini Intel Error:", error);
    throw error;
  }
};

export const generateQuizQuestions = async (intel: any): Promise<any[]> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const prompt = `
    Based on this Daily Intel briefing:
    Case Study: ${intel.caseStudy.company} - ${intel.caseStudy.specific_metric} of ${intel.caseStudy.metric_value}
    Terms: ${intel.powerTerms.map((t: any) => t.name).join(', ')}

    Generate 5 distinct quiz questions.
    Return a JSON array of objects: { id, question, type }
    - type must be one of: "concept", "application", "critical"
    - "concept": explain a specific metric formula or strategy
    - "application": how to apply this to an operational challenge
    - "critical": "Skeptical board member / what is wrong with this metric interpretation" styled probe
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    const questions = JSON.parse(response.text || "[]");
    return questions.map((q: any) => ({ ...q, id: Math.random().toString() }));
  } catch (error) {
    console.error("Gemini Quiz Questions Error:", error);
    return [];
  }
};

export const evaluateQuizAnswer = async (
  question: string, 
  answer: string, 
  userProfile?: any, 
  recentScores?: any
): Promise<any> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const profile = userProfile || {};

  const prompt = `
    SYSTEM:
    You are Eitan Caspi, growth mentor reviewing an operator's answer to a diagnostic quiz.
    
    Question Asked: ${question}
    Operator's Written Answer: ${answer}
    User Recent Weaknesses: ${JSON.stringify(profile.stated_weaknesses || [])}

    Evaluate the operator's response for rigor, quantitative accuracy, and strategic soundness.
    
    Evaluate the user's answer and return a JSON response with:
    - score: number (1 to 5 stars)
    - correct_observations: [string array of specific things they got right, quoting or referencing their direct words]
    - gaps: [string array of specific concepts they missed, with names of professional frameworks]
    - betterAnswer: "The model/canonical answer they should have provided to show 5-star mastery"
    - rewrite_of_their_answer: "Quote their raw sentence or answer directly, but slightly edit it in a 'track-changes' style (adding/removing words enclosed in bracket markers like [+added+] or [-removed-]) to show exactly how they could have phrased it better."
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    
    const parsed = JSON.parse(response.text || "{}");
    return {
      score: parsed.score || parsed.stars || 3,
      whatRight: String(parsed.correct_observations || parsed.whatRight || "Good baseline logic"),
      whatMissed: String(parsed.gaps || parsed.whatMissed || "Missing exact growth calculation bounds"),
      betterAnswer: String(parsed.betterAnswer || "Focus on retention models first."),
      rewrite_of_their_answer: String(parsed.rewrite_of_their_answer || answer)
    };
  } catch (error) {
    console.error("Gemini Evaluation Error:", error);
    throw error;
  }
};

export const generateGrowthScenario = async (
  roadmapTitle: string, 
  concepts: string[], 
  userProfile?: any
): Promise<GrowthScenario> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const profile = userProfile || {
    business: "B2B SaaS, 18-person seed stage",
    current_focus_okrs: ["improve retention"]
  };

  const prompt = `
    SYSTEM:
    You are Eitan Caspi, advising this operator on a realistic, high-stakes 90-day crisis or strategic scenario based on: "${roadmapTitle}".
    Concepts: ${concepts.join(', ')}.
    User Business context: ${JSON.stringify(profile)}

    Return a challenging Business Decision Sandbox JSON containing:
    1. scenarioTitle: string (eg "The Retention Cascade Failure")
    2. scenarioContext: string (A highly engaging 2-3 sentence strategic briefing detailing a crisis)
    3. options: An array of exactly 3 tactical choices. Each choice has:
       - id: string ("1", "2", "3")
       - label: string (Strategic proposal, 1 sentence)
       - outcome: string (A narrative detailing the tactical consequences of this choice and lessons)
       - metricsImpact: {
           revenue: "Project percentage change eg '+8.5%' or '-4.2%'",
           conversion: "Project percentage point change eg '+1.2 pp' or '-3.0 pp'",
           retention: "Project percentage point change eg '+5.0 pp' or 'Neutral'"
         }
    4. trapdoor_warning: "The option that looks clean and intuitive but acts as a fatal trap, with direct explanation of why."

    Make the constraints highly specific to their business. Reference a real Q1 2026 industry movement using real numbers.
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    const parsed = JSON.parse(response.text || "{}");
    return {
      scenarioTitle: parsed.scenarioTitle || "Tactical Growth Cascade",
      scenarioContext: parsed.scenarioContext || "Friction has risen on conversion funnels.",
      options: parsed.options || [],
      trapdoor_warning: parsed.trapdoor_warning || "Watch out for premature pricing changes without cohort segment validation."
    } as any;
  } catch (error) {
    console.error("Gemini Scenario Error:", error);
    throw error;
  }
};

export const generateReflectionPlan = async (journalText: string, roadmapTitle: string): Promise<ReflectionPlan> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const prompt = `
    Based on the operator's daily reflection log:
    "${journalText}"
    
    And the current roadmap module: "${roadmapTitle}"

    Analyze how they intend to translate theory into practice and synthesize:
    1. actionSteps: exactly 3 highly specific, immediate tactical tasks they should complete in their own business in the next 48 hours.
    2. systemWarning: a critical error pattern, risk, or strategic pitfall they must steer clear of while executing.
    3. kpiIndicators: exactly 2 metric/KPI markers they should track to measure success of this implementation.

    Provide a JSON response with fields: actionSteps, systemWarning, kpiIndicators.
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Error:", error);
    throw error;
  }
};

// NEW SERVICES FROM THE PRIORITY IMPROVEMENT SPECIFICATION

export const generateCaseJournalResolution = async (
  problem: string,
  roadmapTitle: string,
  userProfile?: any,
  antiCliches?: string[]
): Promise<any> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const profile = userProfile || {};
  const cliches = antiCliches || [];

  const prompt = `
    SYSTEM:
    You are Eitan Caspi, growth advisor. The operator has submitted a raw, messy real-work problem. You must help them resolve it using the framework: "${roadmapTitle}" and their business profiles: ${JSON.stringify(profile)}.
    Avoid clichés: ${cliches.join(', ')}.

    Provide a highly actionable resolution roadmap. Return JSON targeting:
    - situationKey: "A 1-sentence diagnostic of the true bottleneck under this problem"
    - strategicFramework: "The exact name of the strategic model or formula that solves this"
    - tacticalPlan: [exactly 3 clear, ordered execution steps]
    - thirtyMinuteNextAction: "The single, highest-leverage operational step they can take in the NEXT 30 MINUTES to begin solving this."
    - metricsToTrack: ["exactly 2 key quantitative metrics they should monitor"]
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Journal Resolution Error:", error);
    throw error;
  }
};

export const evaluateStrategyRedTeam = async (
  thesis: string,
  userProfile?: any
): Promise<any> => {
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({ apiKey: apiKey || "" });

  const profile = userProfile || {};

  const prompt = `
    SYSTEM:
    You are Eitan Caspi playing the role of a highly skeptical, combative Board Member (an adversarial advisor). 
    Your job is to red-team the operator's business decision, pitch, or growth hypothesis. 
    You hate sloppy reasoning. You must dissect their strategy and expose the exact points where it will break.
    
    Operator Thesis: "${thesis}"
    Operator Business background: ${JSON.stringify(profile)}

    Analyze this proposal and return JSON with:
    - critiques: [exactly 3 brutal, logical counter-arguments detailing risks or why their plan might collapse]
    - rating: number from 1 to 10 (on how defensible/rigorous their thesis is. Be strict.)
    - keyWeakness: "The single highest-risk vulnerability or leap of faith in their plan"
    - trapdoor_warning: "The dangerous logical trap they are falling into (the action that looks right but is fatal)"
  `;

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Red Team Error:", error);
    throw error;
  }
};


